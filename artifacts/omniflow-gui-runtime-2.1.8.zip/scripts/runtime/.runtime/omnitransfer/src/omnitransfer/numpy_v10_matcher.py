"""Pure-NumPy inference for the canonical OmniTransfer V10 matcher.

The training/runtime model is still the one defined by ``geometric_matcher``.
This module is only its frozen inference backend: it contains the same V10
node encoder, point-conditioned graph learner, sparse graph update, cross-page
refinement, assignment and 1024-dimensional page readout, without importing
PyTorch on the phone.
"""

from __future__ import annotations

import json
import math
import hashlib
from collections import OrderedDict
from dataclasses import asdict
from io import BytesIO
from pathlib import Path
from typing import Any, Mapping
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from omnitransfer.learned_matcher import (
    ALL_NODE_CANDIDATE_POLICY,
    BoundedRelations,
    MatcherConfig,
    POINT_CONDITIONED_SPARSE_GRAPH_ARCHITECTURE,
    RELATION_FEATURE_DIM,
    encode_graph,
)
from omnitransfer.numpy_v9_matcher import (
    NumpyGeometricAlignmentMatcher,
    _gelu,
    _log_softmax,
    _mutual_log_assignment,
    _require_numpy,
    _softmax,
    _visual_inputs,
    np_float,
)


NUMPY_POINT_CONDITIONED_SPARSE_GRAPH_SCHEMA = (
    "omnitransfer_numpy_point_conditioned_sparse_graph_v10"
)


class NumpyPointConditionedSparseGraphMatcher(NumpyGeometricAlignmentMatcher):
    """Inference-only NumPy implementation of OmniTransfer V10."""

    _GRAPH_CACHE_LIMIT = 16

    feature_schema_id = "omnitransfer-state-aware-v9"
    backend = "numpy-point-conditioned-sparse-graph-v10"

    def __init__(self, weights: Mapping[str, Any], *, config: MatcherConfig) -> None:
        if config.architecture != POINT_CONDITIONED_SPARSE_GRAPH_ARCHITECTURE:
            raise ValueError("NumPy V10 requires point-conditioned sparse graph architecture")
        if config.candidate_policy != ALL_NODE_CANDIDATE_POLICY:
            raise ValueError("the matcher requires the all-node candidate policy")
        if config.local_neighbor_limit != 0:
            raise ValueError("NumPy V10 requires variable local graph support")
        self.weights = dict(weights)
        self.config = config
        self.feature_schema_id = config.feature_schema_id
        self.page_embedding_dim = int(config.state_embedding_dim)
        # Function source states are immutable evidence and are commonly
        # reused across replay runs. Cache only derived read-only inputs; the
        # cross-page forward pass remains unchanged.
        self._encoded_graph_cache: OrderedDict[str, Any] = OrderedDict()
        self._visual_input_cache: OrderedDict[str, tuple[Any, Any]] = OrderedDict()

    @classmethod
    def from_checkpoint(
        cls, path: str | Path
    ) -> "NumpyPointConditionedSparseGraphMatcher":
        np = _require_numpy()
        with np.load(Path(path), allow_pickle=False) as checkpoint:
            schema = _decode(checkpoint["__schema_version__"])
            if schema != NUMPY_POINT_CONDITIONED_SPARSE_GRAPH_SCHEMA:
                raise ValueError("checkpoint is not an OmniTransfer NumPy V10 matcher")
            config = MatcherConfig(**json.loads(_decode(checkpoint["__config_json__"])))
            weights = {
                name: checkpoint[name].astype(np.float32, copy=True)
                for name in checkpoint.files
                if not name.startswith("__")
            }
        return cls(weights, config=config)

    def _forward(self, source: Any, target: Any) -> dict[str, Any]:
        np = _require_numpy()
        source_encoded = self._encoded_graph(source)
        target_encoded = self._encoded_graph(target)
        source_tokens = np.asarray(source_encoded.token_ids, dtype=np.int64)
        target_tokens = np.asarray(target_encoded.token_ids, dtype=np.int64)
        source_numeric = np.asarray(source_encoded.numeric_features, dtype=np.float32)
        target_numeric = np.asarray(target_encoded.numeric_features, dtype=np.float32)
        source_relations = _bounded_arrays(source_encoded.relation_features)
        target_relations = _bounded_arrays(target_encoded.relation_features)
        source_visual, source_visual_mask = self._visual_inputs(source)
        target_visual, target_visual_mask = self._visual_inputs(target)
        source_states, source_route, source_text_mask = self._encode_nodes(
            source_tokens, source_numeric, source_visual, source_visual_mask
        )
        target_states, target_route, target_text_mask = self._encode_nodes(
            target_tokens, target_numeric, target_visual, target_visual_mask
        )
        source_graph = self._encode_sparse_page(
            source_states, source_relations, source_numeric
        )
        target_graph = self._encode_sparse_page(
            target_states, target_relations, target_numeric
        )
        source_states = source_graph["states"]
        target_states = target_graph["states"]
        unary_affinity, _, _ = self._affinity(source_states, target_states)
        logits = _mutual_log_assignment(unary_affinity)
        assignments: list[Any] = []
        affinities: list[Any] = []
        local_corrections: list[Any] = []
        source_states_by_layer: list[Any] = []
        target_states_by_layer: list[Any] = []
        for layer_index in range(self.config.association_layers):
            source_states, target_states = self._contextual_layer_v10(
                source_states, target_states, layer_index
            )
            pair_features = _pair_features(source_states, target_states)
            soft_correspondence = _soft_correspondence(logits)
            local_context, _, _, _ = self._sparse_graph_match(
                pair_features,
                soft_correspondence,
                source_graph,
                target_graph,
            )
            local_correction = self._linear_pair_scorer(
                pair_features, local_context
            )
            backbone_affinity, _, _ = self._affinity(source_states, target_states)
            logits = _mutual_log_assignment(backbone_affinity) + local_correction
            assignments.append(logits)
            affinities.append(backbone_affinity)
            local_corrections.append(local_correction)
            source_states_by_layer.append(source_states)
            target_states_by_layer.append(target_states)
        final_affinity, source_matchability, target_matchability = self._affinity(
            source_states, target_states
        )
        final_assignment = _mutual_log_assignment(final_affinity) + local_corrections[-1]
        return {
            "logits_ab": final_assignment,
            "affinity": final_affinity + local_corrections[-1],
            "association_score": final_affinity + local_corrections[-1],
            "unary_affinity": unary_affinity,
            "assignment_scores_by_layer": tuple(assignments),
            "affinities_by_layer": tuple(
                affinity + correction
                for affinity, correction in zip(affinities, local_corrections)
            ),
            "local_corrections_by_layer": tuple(local_corrections),
            "source_matchability": source_matchability,
            "target_matchability": target_matchability,
            "source_config_embedding": self._state_embedding(
                source_graph["states"], source_route, source_numeric, source_text_mask
            ),
            "target_config_embedding": self._state_embedding(
                target_graph["states"], target_route, target_numeric, target_text_mask
            ),
            "alignment_strategy_schema": "omnitransfer.alignment-strategy.v1",
            "association_schema": "omnitransfer.unified-association.v1",
        }

    def _encoded_graph(self, graph: Any) -> Any:
        key = _graph_semantic_cache_key(graph)
        cached = self._encoded_graph_cache.get(key)
        if cached is not None:
            self._encoded_graph_cache.move_to_end(key)
            return cached
        encoded = encode_graph(
            graph, config=self.config, feature_schema_id=self.feature_schema_id
        )
        self._encoded_graph_cache[key] = encoded
        self._encoded_graph_cache.move_to_end(key)
        while len(self._encoded_graph_cache) > self._GRAPH_CACHE_LIMIT:
            self._encoded_graph_cache.popitem(last=False)
        return encoded

    def _visual_inputs(self, graph: Any) -> tuple[Any, Any]:
        key = _graph_visual_cache_key(graph)
        cached = self._visual_input_cache.get(key)
        if cached is not None:
            self._visual_input_cache.move_to_end(key)
            return cached
        value = _visual_inputs(
            graph,
            patch_size=self.config.visual_patch_size,
            canvas_size=self.config.visual_canvas_size,
            visual_encoder=self.config.visual_encoder,
            context_scale=self.config.visual_context_scale,
        )
        for array in value:
            if hasattr(array, "setflags"):
                array.setflags(write=False)
        self._visual_input_cache[key] = value
        self._visual_input_cache.move_to_end(key)
        while len(self._visual_input_cache) > self._GRAPH_CACHE_LIMIT:
            self._visual_input_cache.popitem(last=False)
        return value

    def _encode_nodes(
        self, token_ids: Any, numeric: Any, visual_patches: Any, visual_mask: Any
    ) -> tuple[Any, Any, Any]:
        np = _require_numpy()
        visual = self._deterministic_visual(visual_patches)
        visual = visual_mask * visual + (1.0 - visual_mask) * self.weights[
            "missing_visual"
        ][None]
        text_mask = (token_ids != 0).any(axis=1, keepdims=True).astype(np.float32)
        token_vectors = self.weights["token_embedding.weight"][token_ids]
        token_mask = (token_ids != 0).astype(np.float32)[..., None]
        text = self._linear(
            (token_vectors * token_mask).sum(axis=1)
            / np.maximum(token_mask.sum(axis=1), 1.0),
            "text_projection",
        )
        text = text_mask * text + (1.0 - text_mask) * self.weights["missing_text"][None]
        xml = self._layer_norm(numeric, "xml_projection.0")
        xml = _gelu(self._linear(xml, "xml_projection.1"))
        xml = self._linear(xml, "xml_projection.3")
        modalities = np.stack(
            (
                self._linear(text, "text_to_hidden"),
                self._linear(visual, "visual_to_hidden"),
                self._linear(xml, "xml_to_hidden"),
            ),
            axis=1,
        ) + self.weights["modality_type"][None]
        available = np.concatenate(
            (text_mask, visual_mask.astype(np.float32), np.ones_like(text_mask)), axis=1
        )
        modality_logits = self._linear(
            self._layer_norm(modalities, "modality_score.0"),
            "modality_score.1",
            bias=False,
        ).squeeze(-1)
        modality_logits = np.where(available > 0.0, modality_logits, np_float(-1e4))
        route = _softmax(
            modality_logits / np_float(self.config.router_temperature), axis=1
        )
        fused = (route[..., None] * modalities).sum(axis=1, dtype=np.float32)
        states = self._layer_norm(fused, "input_norm")
        feed_forward = _gelu(self._linear(states, "input_feed_forward.0"))
        states = self._layer_norm(
            states + self._linear(feed_forward, "input_feed_forward.3"),
            "input_output_norm",
        )
        return states, route, text_mask

    def _deterministic_visual(self, patches: Any) -> Any:
        from omnitransfer.visual_descriptor import deterministic_icon_descriptor_numpy

        if self.config.visual_encoder != "deterministic_icon_v1":
            raise ValueError("NumPy V10 mobile runtime requires deterministic_icon_v1")
        return deterministic_icon_descriptor_numpy(patches)

    def _encode_sparse_page(
        self, states: Any, relations: BoundedRelations, numeric: Any
    ) -> dict[str, Any]:
        features = relations.features
        neighbor_indices = relations.neighbor_indices
        mask = relations.mask
        graph_layers = []
        for layer_index in range(self.config.local_graph_layers):
            prefix = f"sparse_graph_learners.{layer_index}"
            graph = self._learn_graph(states, features, neighbor_indices, mask, numeric, prefix)
            graph_layers.append(graph)
            states = self._sparse_graph_update(
                states,
                features,
                neighbor_indices,
                graph["edge_weights"],
                f"sparse_graph_updates.{layer_index}",
            )
        edge_tokens = self._relation_encoder(states, features, neighbor_indices)
        graph = graph_layers[-1]
        graph.update(
            {
                "states": states,
                "neighbor_indices": neighbor_indices,
                "edge_tokens": edge_tokens,
                "layers": tuple(graph_layers),
            }
        )
        return graph

    def _learn_graph(
        self,
        states: Any,
        features: Any,
        neighbor_indices: Any,
        mask: Any,
        numeric: Any,
        prefix: str,
    ) -> dict[str, Any]:
        np = _require_numpy()
        bbox_present = numeric[:, 4] > 0.0
        bbox_pair = bbox_present[:, None] & bbox_present[neighbor_indices]
        spatial_distance = np.sqrt(features[..., 11] ** 2 + features[..., 12] ** 2)
        spatial_local = bbox_pair & (spatial_distance <= self.config.local_spatial_radius)
        structural_local = (
            (features[..., 1:6] > 0.0).any(axis=-1)
            & (features[..., 16] <= self.config.local_tree_hops / 16.0)
        )
        available = mask & (spatial_local | structural_local)
        raw_bandwidth = _sigmoid(
            self._linear(self._layer_norm(states, f"{prefix}.bandwidth.0"), f"{prefix}.bandwidth.1")
        )
        spatial_bandwidth = 0.05 + raw_bandwidth[:, 0] * self.config.local_spatial_radius
        tree_bandwidth = (1.0 + raw_bandwidth[:, 1] * self.config.local_tree_hops) / 16.0
        query = self._linear(states, f"{prefix}.query", bias=False)
        key = self._linear(states, f"{prefix}.key", bias=False)
        point_score = np.sum(
            query[:, None, :] * key[neighbor_indices], axis=-1
        ) / np_float(math.sqrt(self.config.relation_hidden_dim))
        relation_score = self._linear(
            _gelu(
                self._linear(
                    self._layer_norm(features, f"{prefix}.relation_score.0"),
                    f"{prefix}.relation_score.1",
                )
            ),
            f"{prefix}.relation_score.3",
            bias=False,
        ).squeeze(-1)
        spatial_penalty = np.where(
            spatial_local, spatial_distance / spatial_bandwidth[:, None], 0.0
        )
        tree_penalty = np.where(
            structural_local, features[..., 16] / tree_bandwidth[:, None], 0.0
        )
        edge_scores = point_score + relation_score - spatial_penalty - tree_penalty
        edge_scores = np.where(available, edge_scores, np_float(-1e4))
        null_score = self._linear(
            self._layer_norm(states, f"{prefix}.null_score.0"),
            f"{prefix}.null_score.1",
        )
        distribution = _entmax15(
            np.concatenate((edge_scores, null_score), axis=1), axis=1
        )
        edge_weights = distribution[:, :-1] * available.astype(np.float32)
        return {
            "locality_mask": available,
            "neighbor_indices": neighbor_indices,
            "edge_scores": edge_scores,
            "edge_weights": edge_weights,
            "null_weights": distribution[:, -1],
            "bandwidths": np.stack((spatial_bandwidth, tree_bandwidth * 16.0), axis=1),
        }

    def _sparse_graph_update(
        self,
        states: Any,
        features: Any,
        neighbor_indices: Any,
        edge_weights: Any,
        prefix: str,
    ) -> Any:
        neighbor_values = self._linear(
            states, f"{prefix}.node_value", bias=False
        )[neighbor_indices]
        edge_messages = neighbor_values + self._gelu_linear(
            features, f"{prefix}.edge_value"
        )
        message = (edge_weights[..., None] * edge_messages).sum(axis=1)
        updated = self._layer_norm(
            states + self._linear(message, f"{prefix}.message_projection", bias=False),
            f"{prefix}.message_norm",
        )
        feed_forward = _gelu(self._linear(updated, f"{prefix}.feed_forward.0"))
        return self._layer_norm(
            updated + self._linear(feed_forward, f"{prefix}.feed_forward.3"),
            f"{prefix}.output_norm",
        )

    def _gelu_linear(self, values: Any, prefix: str) -> Any:
        return _gelu(
            self._linear(
                self._layer_norm(values, f"{prefix}.0"),
                f"{prefix}.1",
            )
        )

    def _relation_encoder(self, states: Any, features: Any, indices: Any) -> Any:
        values = self._require_numpy().concatenate(
            (states[indices], features), axis=-1
        )
        values = self._layer_norm(values, "relation_encoder.0")
        values = _gelu(self._linear(values, "relation_encoder.1"))
        values = self._linear(values, "relation_encoder.3")
        return self._layer_norm(values, "relation_encoder.4")

    def _contextual_layer_v10(
        self, source: Any, target: Any, layer_index: int
    ) -> tuple[Any, Any]:
        prefix = f"association_layers.{layer_index}"
        source_context = self._cross_context_v10(source, target, prefix)
        target_context = self._cross_context_v10(target, source, prefix)
        return (
            self._cross_update_v10(source, source_context, prefix),
            self._cross_update_v10(target, target_context, prefix),
        )

    def _cross_context_v10(self, query_states: Any, key_states: Any, prefix: str) -> Any:
        query = self._linear(query_states, f"{prefix}.query", bias=False)
        key = self._linear(key_states, f"{prefix}.key", bias=False)
        scores = (query @ key.T) / np_float(math.sqrt(self.config.hidden_dim))
        values = self._linear(key_states, f"{prefix}.value", bias=False)
        return _softmax(scores, axis=-1) @ values

    def _cross_update_v10(self, states: Any, context: Any, prefix: str) -> Any:
        np = _require_numpy()
        evidence = np.concatenate(
            (states, context, np.abs(states - context), states * context), axis=-1
        )
        update = self._layer_norm(evidence, f"{prefix}.cross_update.0")
        update = _gelu(self._linear(update, f"{prefix}.cross_update.1"))
        update = self._linear(update, f"{prefix}.cross_update.4")
        return self._layer_norm(states + update, f"{prefix}.cross_norm")

    def _sparse_graph_match(
        self,
        pair_features: Any,
        soft_correspondence: Any,
        source_graph: dict[str, Any],
        target_graph: dict[str, Any],
    ) -> tuple[Any, Any, Any, Any]:
        np = _require_numpy()
        source_edges = source_graph["edge_weights"][..., None] * source_graph["edge_tokens"]
        target_edges = target_graph["edge_weights"][..., None] * target_graph["edge_tokens"]
        source_indices = source_graph["neighbor_indices"]
        target_indices = target_graph["neighbor_indices"]
        source_correspondence = soft_correspondence[source_indices]
        source_aligned = np.einsum("ikr,ikm->imr", source_edges, source_correspondence)
        source_support = np.einsum("ik,ikm->im", source_graph["edge_weights"], source_correspondence)
        relation_consistency = np.zeros(
            (*pair_features.shape[:2], source_graph["edge_tokens"].shape[-1]),
            dtype=np.float32,
        )
        graph_support = np.zeros_like(soft_correspondence)
        for slot in range(target_indices.shape[1]):
            target_slot = target_indices[:, slot]
            relation_consistency += source_aligned[:, target_slot, :] * target_edges[:, slot, :][None]
            graph_support += source_support[:, target_slot] * target_graph["edge_weights"][:, slot][None]
        source_mass = source_graph["edge_weights"].sum(axis=1)
        target_mass = target_graph["edge_weights"].sum(axis=1)
        available_mass = source_mass[:, None] * target_mass[None, :]
        stable_mass = np_float(1e-4)
        normalized_support = np.where(
            available_mass > stable_mass,
            graph_support / np.maximum(available_mass, stable_mass),
            0.0,
        )
        normalized_consistency = relation_consistency / np.maximum(
            graph_support[..., None], stable_mass
        )
        normalized_consistency = np.where(
            graph_support[..., None] > stable_mass, normalized_consistency, 0.0
        )
        query = self._relation_query(pair_features)
        scaled_consistency = self.weights["graph_prior_scale"] * normalized_consistency
        context = self._local_pair(
            np.concatenate(
                (
                    query,
                    scaled_consistency,
                    np.abs(query - scaled_consistency),
                    query * scaled_consistency,
                    graph_support[..., None],
                    normalized_support[..., None],
                ),
                axis=-1,
            )
        )
        support = np.stack((graph_support, normalized_support), axis=-1)
        return context, graph_support, graph_support, support

    def _relation_query(self, pair_features: Any) -> Any:
        np = _require_numpy()
        values = self._layer_norm(pair_features, "relation_query.0")
        return np.tanh(self._linear(values, "relation_query.1"))

    def _local_pair(self, values: Any) -> Any:
        values = self._layer_norm(values, "local_pair.0")
        values = _gelu(self._linear(values, "local_pair.1"))
        return self._linear(values, "local_pair.3")

    def _linear_pair_scorer(self, pair_features: Any, local_context: Any) -> Any:
        values = self._layer_norm(
            _require_numpy().concatenate((pair_features, local_context), axis=-1),
            "pair_scorer.0",
        )
        values = _gelu(self._linear(values, "pair_scorer.1"))
        return self._linear(values, "pair_scorer.4").squeeze(-1)

    def _state_embedding(
        self, states: Any, route: Any, numeric: Any, text_mask: Any
    ) -> Any:
        del numeric, text_mask
        np = _require_numpy()
        slot_logits = self._linear(states, "state_attention", bias=False).T
        semantic_mass = route[:, 0] + route[:, 2] + np_float(0.10) * route[:, 1]
        slot_logits += np.log(np.maximum(semantic_mass, np_float(1e-12)))[None]
        slot_weights = _softmax(slot_logits, axis=1)
        slots = slot_weights @ states
        slots /= np.maximum(np.linalg.norm(slots, axis=-1, keepdims=True), np_float(1e-12))
        embedding = slots.reshape(-1)
        return embedding / np.maximum(np.linalg.norm(embedding), np_float(1e-12))

    def _require_numpy(self) -> Any:
        return _require_numpy()


def save_numpy_point_conditioned_sparse_graph_checkpoint(
    path: str | Path,
    state_dict: Mapping[str, Any],
    *,
    config: MatcherConfig,
) -> None:
    """Export the exact V10 state dict as a pickle-free deterministic NPZ."""

    if config.architecture != POINT_CONDITIONED_SPARSE_GRAPH_ARCHITECTURE:
        raise ValueError("only point-conditioned sparse graph V10 can use this exporter")
    np = _require_numpy()
    arrays: dict[str, Any] = {
        "__schema_version__": _encode(NUMPY_POINT_CONDITIONED_SPARSE_GRAPH_SCHEMA),
        "__config_json__": _encode(
            json.dumps(asdict(config), sort_keys=True, separators=(",", ":"))
        ),
    }
    for name, value in state_dict.items():
        if hasattr(value, "detach"):
            value = value.detach().cpu().numpy()
        arrays[name] = np.asarray(value, dtype=np.float32)
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    with ZipFile(temporary, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(arrays):
            buffer = BytesIO()
            np.lib.format.write_array(buffer, arrays[name], allow_pickle=False)
            info = ZipInfo(f"{name}.npy", date_time=(1981, 1, 1, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(
                info,
                buffer.getvalue(),
                compress_type=ZIP_DEFLATED,
                compresslevel=9,
            )
    temporary.replace(output)


def load_numpy_matcher(path: str | Path) -> Any:
    """Load either supported frozen NumPy backend without changing the API."""

    np = _require_numpy()
    with np.load(Path(path), allow_pickle=False) as checkpoint:
        schema = _decode(checkpoint["__schema_version__"])
    if schema == NUMPY_POINT_CONDITIONED_SPARSE_GRAPH_SCHEMA:
        return NumpyPointConditionedSparseGraphMatcher.from_checkpoint(path)
    return NumpyGeometricAlignmentMatcher.from_checkpoint(path)


def _graph_semantic_cache_key(graph: Any) -> str:
    """Fingerprint only fields consumed by ``encode_graph``.

    Screenshot identity is intentionally excluded: XML-derived node features
    remain reusable when a new screenshot is captured for the same hierarchy.
    """

    nodes = []
    for node in graph.nodes:
        nodes.append(
            {
                "node_id": node.node_id,
                "origin_id": node.origin_id,
                "parent_id": node.parent_id,
                "text": node.text,
                "content_desc": node.content_desc,
                "resource_id": node.resource_id,
                "class_name": node.class_name,
                "bbox": node.bbox,
                "clickable": node.clickable,
                "editable": node.editable,
                "scrollable": node.scrollable,
                "enabled": node.enabled,
                "depth": node.depth,
                "child_ids": node.child_ids,
                "metadata": node.metadata,
            }
        )
    payload = json.dumps(
        {"width": graph.width, "height": graph.height, "nodes": nodes},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=repr,
    ).encode("utf-8")
    return hashlib.blake2b(payload, digest_size=16).hexdigest()


def _graph_visual_cache_key(graph: Any) -> str:
    """Fingerprint XML geometry plus the immutable visual evidence identity."""

    metadata = graph.metadata if isinstance(graph.metadata, dict) else {}
    screenshot_path = str(metadata.get("screenshot_path") or "")
    screenshot_signature: tuple[Any, ...] = (screenshot_path,)
    if screenshot_path:
        try:
            stat = Path(screenshot_path).stat()
            screenshot_signature += (int(stat.st_mtime_ns), int(stat.st_size))
        except OSError:
            pass
    visual_rgb = metadata.get("visual_rgb")
    visual_digest = hashlib.blake2b(
        json.dumps(
            visual_rgb,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=repr,
        ).encode("utf-8"),
        digest_size=16,
    ).hexdigest() if visual_rgb is not None else ""
    payload = {
        "semantic": _graph_semantic_cache_key(graph),
        "screenshot": screenshot_signature,
        "visual_rgb": visual_digest,
    }
    return hashlib.blake2b(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8"),
        digest_size=16,
    ).hexdigest()


def _bounded_arrays(value: Any) -> BoundedRelations:
    np = _require_numpy()
    if not isinstance(value, BoundedRelations):
        raise TypeError("OmniTransfer V10 requires bounded relation inputs")
    return BoundedRelations(
        features=np.asarray(value.features, dtype=np.float32),
        neighbor_indices=np.asarray(value.neighbor_indices, dtype=np.int64),
        mask=np.asarray(value.mask, dtype=bool),
    )


def _pair_features(source: Any, target: Any) -> Any:
    np = _require_numpy()
    source_grid = source[:, None, :]
    target_grid = target[None, :, :]
    return np.concatenate(
        (
            np.broadcast_to(source_grid, (len(source), len(target), source.shape[-1])),
            np.broadcast_to(target_grid, (len(source), len(target), target.shape[-1])),
            np.abs(source_grid - target_grid),
            source_grid * target_grid,
        ),
        axis=-1,
    )


def _soft_correspondence(logits: Any) -> Any:
    np = _require_numpy()
    return np_float(0.5) * (_softmax(logits, axis=1) + _softmax(logits, axis=0))


def _entmax15(values: Any, *, axis: int) -> Any:
    np = _require_numpy()
    scaled = values / np_float(2.0)
    scaled = scaled - np.max(scaled, axis=axis, keepdims=True)
    sorted_values = np.sort(scaled, axis=axis)[:, ::-1]
    dimension = sorted_values.shape[axis]
    rho = np.arange(1, dimension + 1, dtype=np.float32)[None, :]
    mean = np.cumsum(sorted_values, axis=axis) / rho
    mean_square = np.cumsum(sorted_values * sorted_values, axis=axis) / rho
    variance_sum = rho * (mean_square - mean * mean)
    delta = (np_float(1.0) - variance_sum) / rho
    taus = mean - np.sqrt(np.maximum(delta, np.finfo(np.float32).eps))
    support = taus <= sorted_values
    support_size = np.maximum(support.sum(axis=axis, keepdims=True), 1)
    tau_star = np.take_along_axis(taus, support_size - 1, axis=axis)
    probabilities = np.maximum(scaled - tau_star, 0.0) ** 2
    return probabilities / np.maximum(
        probabilities.sum(axis=axis, keepdims=True), np.finfo(np.float32).eps
    )


def _sigmoid(values: Any) -> Any:
    np = _require_numpy()
    return np_float(1.0) / (np_float(1.0) + np.exp(-values))


def _encode(value: str) -> Any:
    np = _require_numpy()
    return np.frombuffer(value.encode("utf-8"), dtype=np.uint8).copy()


def _decode(value: Any) -> str:
    np = _require_numpy()
    return value.astype(np.uint8, copy=False).tobytes().decode("utf-8")
