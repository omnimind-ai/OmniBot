"""Stable replay-time action transfer interface."""

from __future__ import annotations

from functools import lru_cache
import hashlib
import math
from pathlib import Path
from typing import Any

from omnitransfer.numpy_v9_matcher import NumpyGeometricAlignmentMatcher
from omnitransfer.page_embedding import (
    DEFAULT_PAGE_EMBEDDING_CHECKPOINT,
    DEFAULT_PAGE_EMBEDDING_CHECKPOINT_SHA256,
)
from omnitransfer.unified_alignment import (
    ALIGNMENT_STRATEGY_SCHEMA_ID,
    TRANSFER_CONTRACT_SCHEMA_ID,
    TransferRequest,
    transfer_contract_metadata,
)
from omnitransfer.ui_graph import UIGraph, UINode, graph_from_record

_MIN_ANCHOR_OFFSET = -1.0
_MAX_ANCHOR_OFFSET = 2.0
_MATCHER_RELEASE = "omnitransfer-unified-association-v1-mobile"
_MATCHER_MODE = "omnitransfer_unified_association_v1"
_DEFAULT_MATCHER_CHECKPOINT = DEFAULT_PAGE_EMBEDDING_CHECKPOINT
_DEFAULT_MATCHER_SHA256 = DEFAULT_PAGE_EMBEDDING_CHECKPOINT_SHA256
_MATCHER_FEATURE_SCHEMA_ID = "omnitransfer-unified-association-v1"
_MATCHER_FEATURE_SCHEMA_SPEC = (
    "node_encoder=learned_token_lookup,content_desc,class,action_state,deterministic_icon_v1;"
    "modality_fusion=sharp_learned_attention_missing_aware;"
    "within_page_relations=typed_hierarchy,sibling,ancestor,descendant,row,column,"
    "overlap,neighbors,near,control_context;"
    "refinement=three_layer_local_graph_plus_bidirectional_cross_page_attention;"
    "assignment=partial_bidirectional_matchability;"
    "page_embedding=attention_pool_normalized;"
    "forbidden=resource_id_lookup,node_id_lookup,raw_absolute_position,"
    "source_coordinate_passthrough,app_identity"
)
_MATCHER_FEATURE_SCHEMA_SHA256 = hashlib.sha256(
    _MATCHER_FEATURE_SCHEMA_SPEC.encode("utf-8")
).hexdigest()
_CANDIDATE_RANKING_SCHEMA_VERSION = "omnitransfer.candidate-ranking.v1"


def rank_action_candidates(
    *,
    target_xml: str,
    source_xml: str | None = None,
    source_point: tuple[float, float] | None = None,
    source_element_id: str | None = None,
    source_offset: tuple[float, float] | None = None,
    source_screenshot_path: str | None = None,
    target_screenshot_path: str | None = None,
    source_visual_rgb: dict[str, Any] | None = None,
    target_visual_rgb: dict[str, Any] | None = None,
    action_type: str = "click",
    top_k: int = 1,
) -> dict[str, Any]:
    """Return the complete candidate ranking without accepting or rejecting it.

    Confidence and page-identity policy belong to the caller. This API only
    validates the inputs required to score, runs the matcher, and projects the
    recorded within-node offset onto every ranked target candidate.
    """

    request = TransferRequest(
        target_xml=target_xml,
        source_xml=source_xml,
        source_point=source_point,
        source_element_id=source_element_id,
        source_offset=source_offset,
        source_screenshot_path=source_screenshot_path,
        target_screenshot_path=target_screenshot_path,
        source_visual_rgb=source_visual_rgb,
        target_visual_rgb=target_visual_rgb,
        action_type=action_type,
        top_k=top_k,
    )
    if not request.source_xml:
        return _candidate_ranking_result(
            status="invalid_input",
            reason="source_graph_required",
            action_type=action_type,
            top_k=top_k,
        )
    try:
        source = graph_from_record(
            {
                "xml": request.source_xml,
                "screenshot_path": request.source_screenshot_path,
                "visual_rgb": request.source_visual_rgb,
            },
            graph_id="source",
        )
        target = graph_from_record(
            {
                "xml": request.target_xml,
                "screenshot_path": request.target_screenshot_path,
                "visual_rgb": request.target_visual_rgb,
            },
            graph_id="target",
        )
    except Exception as error:
        return _candidate_ranking_result(
            status="invalid_input",
            reason="graph_parse_failed",
            action_type=action_type,
            top_k=top_k,
            error=str(error) or type(error).__name__,
        )
    source_node = _source_node(
        source,
        request.source_point,
        request.source_element_id,
    )
    if source_node is None:
        return _candidate_ranking_result(
            status="invalid_input",
            reason="source_target_missing",
            source=source,
            target=target,
            action_type=action_type,
            top_k=top_k,
        )
    offset = _source_offset(
        source_node,
        request.source_point,
        request.source_offset,
    )
    if offset is None:
        return _candidate_ranking_result(
            status="invalid_input",
            reason="source_point_or_offset_required",
            source=source,
            target=target,
            source_node=source_node,
            action_type=request.action_type,
            top_k=request.top_k,
        )
    bounded_nodes = tuple(node for node in target.nodes if node.bbox is not None)
    candidate_node_ids = tuple(node.node_id for node in bounded_nodes)
    try:
        matcher = _get_matcher()
        matcher_metadata = _matcher_metadata(matcher)
        match = matcher.predict(
            source,
            target,
            source_node_id=source_node.node_id,
            candidate_node_ids=candidate_node_ids,
            min_probability=0.0,
            min_margin=0.0,
        )
    except Exception as error:
        return _candidate_ranking_result(
            status="matcher_unavailable",
            reason="matcher_unavailable",
            source=source,
            target=target,
            source_node=source_node,
            offset=offset,
            action_type=action_type,
            top_k=top_k,
            error=str(error) or type(error).__name__,
        )
    ranked = _learned_candidates(target, match.scores)
    return _candidate_ranking_result(
        status="scored" if ranked else "no_candidates",
        reason=str(match.reason or ("ranked" if ranked else "target_candidates_missing")),
        source=source,
        target=target,
        source_node=source_node,
        offset=offset,
        ranked=ranked,
        pair_confidence=float(match.probability),
        margin=float(match.margin),
        action_type=request.action_type,
        top_k=request.top_k,
        matcher_metadata=matcher_metadata,
    )


def _candidate_ranking_result(
    *,
    status: str,
    reason: str,
    action_type: str,
    top_k: int,
    mapping_mode: str = _MATCHER_MODE,
    source: UIGraph | None = None,
    target: UIGraph | None = None,
    source_node: UINode | None = None,
    offset: tuple[float, float] | None = None,
    ranked: list[tuple[float, UINode]] | None = None,
    pair_confidence: float | None = None,
    margin: float | None = None,
    error: str | None = None,
    matcher_metadata: dict[str, str] | None = None,
) -> dict[str, Any]:
    ranked_values = list(ranked or ())
    candidates = _projected_candidate_dicts(ranked_values, offset)
    result: dict[str, Any] = {
        "schema_version": _CANDIDATE_RANKING_SCHEMA_VERSION,
        "transfer_contract": TRANSFER_CONTRACT_SCHEMA_ID,
        "pipeline": transfer_contract_metadata(),
        "status": status,
        "reason": reason,
        "mapping_mode": mapping_mode,
        "src_element": _node_dict(source_node) if source_node is not None else {},
        "source_size": _graph_size(source),
        "target_size": _graph_size(target),
        "score": pair_confidence,
        "pair_confidence": pair_confidence,
        "rank_probability": candidates[0]["score"] if candidates else None,
        "margin": margin,
        "candidates": candidates,
        "top_candidates": candidates[: max(1, int(top_k))],
        "action_type": action_type,
    }
    if error:
        result["error"] = error
    if matcher_metadata:
        result.update(matcher_metadata)
    else:
        result["matcher_release"] = _MATCHER_RELEASE
    return result


def _projected_candidate_dicts(
    ranked: list[tuple[float, UINode]],
    offset: tuple[float, float] | None,
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for candidate_score, candidate in ranked:
        bounds = candidate.bbox
        if bounds is None:
            continue
        projected = _project_offset(offset or (0.5, 0.5), bounds)
        candidates.append(
            {
                "candidate_id": _public_node_id(candidate),
                "resource_id": candidate.resource_id,
                "text": candidate.text,
                "content_desc": candidate.content_desc,
                "class": candidate.class_name,
                "bbox": list(bounds),
                "score": float(candidate_score),
                "new_x": projected[0],
                "new_y": projected[1],
            }
        )
    return candidates


def _get_matcher() -> Any:
    return _load_matcher(str(_DEFAULT_MATCHER_CHECKPOINT.resolve()))


@lru_cache(maxsize=4)
def _load_matcher(
    checkpoint: str,
) -> Any:
    path = Path(checkpoint)
    if not path.is_file():
        raise FileNotFoundError(f"OmniTransfer v9 checkpoint missing: {path}")
    if path == _DEFAULT_MATCHER_CHECKPOINT.resolve():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if _DEFAULT_MATCHER_SHA256 and digest != _DEFAULT_MATCHER_SHA256:
            raise ValueError("default OmniTransfer v9 checkpoint checksum mismatch")
    if path.suffix != ".npz":
        raise ValueError("OmniTransfer runtime accepts only the frozen NumPy checkpoint")
    return NumpyGeometricAlignmentMatcher.from_checkpoint(path)


def _matcher_metadata(
    matcher: Any,
) -> dict[str, Any]:
    backend = str(getattr(matcher, "backend", "numpy-unified-association-v1"))
    return {
        "matcher_release": _MATCHER_RELEASE,
        "matcher_backend": backend,
        "matcher_checkpoint_sha256": _DEFAULT_MATCHER_SHA256,
        "matcher_feature_schema": _MATCHER_FEATURE_SCHEMA_ID,
        "matcher_feature_schema_sha256": _MATCHER_FEATURE_SCHEMA_SHA256,
        "alignment_strategy_schema": ALIGNMENT_STRATEGY_SCHEMA_ID,
    }


def _learned_candidates(
    graph: UIGraph,
    scores: tuple[tuple[str, float], ...],
) -> list[tuple[float, UINode]]:
    nodes = {node.node_id: node for node in graph.nodes}
    return sorted(
        (
            (float(score), nodes[node_id])
            for node_id, score in scores
            if node_id in nodes
        ),
        key=lambda item: (-item[0], item[1].node_id),
    )


def _source_node(
    graph: UIGraph,
    point: tuple[float, float] | None,
    element_id: str | None,
) -> UINode | None:
    normalized = str(element_id or "").strip()
    if normalized:
        return next(
            (
                node
                for node in graph.nodes
                if normalized in {
                    node.node_id,
                    node.origin_id,
                    node.resource_id,
                    *(
                        str(alias)
                        for alias in node.metadata.get(
                            "observation_alias_paths",
                            (),
                        )
                    ),
                }
            ),
            None,
        )
    if point is None:
        return None
    x, y = point
    containing = [
        node
        for node in graph.nodes
        if node.bbox is not None
        and node.bbox[0] <= x <= node.bbox[2]
        and node.bbox[1] <= y <= node.bbox[3]
    ]
    return min(
        containing,
        key=lambda node: (
            _area(node.bbox),
            not _has_stable_identity(node),
            -node.depth,
            node.node_id,
        ),
        default=None,
    )


def _has_stable_identity(node: UINode) -> bool:
    return bool(node.resource_id or node.text or node.content_desc)


def _source_offset(
    source: UINode,
    point: tuple[float, float] | None,
    explicit: tuple[float, float] | None,
) -> tuple[float, float] | None:
    if explicit is not None:
        try:
            offset = float(explicit[0]), float(explicit[1])
        except (IndexError, TypeError, ValueError):
            return None
        if not all(
            math.isfinite(value)
            and _MIN_ANCHOR_OFFSET <= value <= _MAX_ANCHOR_OFFSET
            for value in offset
        ):
            return None
        return offset
    if point is not None and source.bbox is not None:
        return _offset(point, source.bbox)
    if source.bbox is not None:
        return 0.5, 0.5
    return None


def _offset(
    point: tuple[float, float],
    bounds: tuple[float, float, float, float],
) -> tuple[float, float]:
    width = max(1.0, bounds[2] - bounds[0])
    height = max(1.0, bounds[3] - bounds[1])
    return (
        _clamp((float(point[0]) - bounds[0]) / width),
        _clamp((float(point[1]) - bounds[1]) / height),
    )


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def _project_offset(
    offset: tuple[float, float],
    target: tuple[float, float, float, float],
) -> tuple[float, float]:
    return (
        target[0] + offset[0] * (target[2] - target[0]),
        target[1] + offset[1] * (target[3] - target[1]),
    )


def _node_dict(node: UINode) -> dict[str, Any]:
    return {
        "id": _public_node_id(node),
        "resource_id": node.resource_id,
        "text": node.text,
        "content_desc": node.content_desc,
        "class": node.class_name,
        "bounds": list(node.bbox or ()),
        "clickable": node.clickable,
        "editable": node.editable,
        "scrollable": node.scrollable,
    }


def _public_node_id(node: UINode) -> str:
    return str(node.resource_id or node.origin_id or node.node_id)


def _graph_size(graph: UIGraph | None) -> list[float] | None:
    if graph is None or graph.width is None or graph.height is None:
        return None
    if graph.width <= 0 or graph.height <= 0:
        return None
    return [graph.width, graph.height]


def _area(bounds: tuple[float, float, float, float] | None) -> float:
    return float("inf") if bounds is None else (bounds[2] - bounds[0]) * (bounds[3] - bounds[1])
