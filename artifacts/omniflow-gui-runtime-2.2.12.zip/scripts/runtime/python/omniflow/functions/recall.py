from __future__ import annotations

from omniflow.runtime.timing import timed

from collections.abc import Mapping
from dataclasses import dataclass
import re
from typing import Any

import numpy as np

from omniflow.core.model import Action, Function, Observation, Transfer, TransferResult
from omniflow.runtime.control import checkpoint, invoke
from omniflow.transfer.embedding import PageEncoder, TreeEmbedding
from omniflow.transfer.runtime import requires_contextual_mapping
from omniflow.transfer.errors import attempt_transfer

RECALL_AUDIT_VERSION = "omniflow.function-recall.v1"
PAGE_SIMILARITY_WEIGHT = 0.30
GOAL_LEXICAL_WEIGHT = 0.70
FUNCTION_PAGE_SIMILARITY_THRESHOLD = 0.80


@dataclass(frozen=True)
class RecallResult:
    functions: tuple[Function, ...]
    audit: dict[str, Any]


async def recall_functions(
    goal: str,
    *,
    observation: Observation,
    functions: dict[str, Function] | list[Function] | tuple[Function, ...],
    source_states: Mapping[str, Observation | None],
    limit: int = 8,
    page_encoder: PageEncoder | None = None,
    transfer: Transfer | None = None,
    exclude_function_ids: frozenset[str] = frozenset(),
) -> RecallResult:
    """Rank Functions, admitting package recovery to run before entry Transfer."""

    checkpoint()
    encoder = page_encoder or await invoke(PageEncoder)
    current_page = await invoke(_embed_page, encoder, observation)
    values = functions.values() if isinstance(functions, dict) else functions
    candidates: list[tuple[float, Function, dict[str, Any]]] = []
    decisions: list[dict[str, Any]] = []

    for function in values:
        checkpoint()
        decision = await invoke(_score_function,
            str(goal),
            function,
            current_observation=observation,
            current_page=current_page,
            source_states=source_states,
            encoder=encoder,
        )
        decisions.append(decision)
        if (
            function.agent_visible
            and function.steps
            and function.id not in exclude_function_ids
        ):
            candidates.append((float(decision["score"]), function, decision))

    ranked = sorted(candidates, key=lambda item: (-item[0], item[1].id))
    coarse_limit = max(0, int(limit)) * 3
    coarse = ranked[:coarse_limit]
    admitted: list[tuple[float, Function, dict[str, Any]]] = []
    for _score, function, decision in coarse:
        decision["coarse_selected"] = True
        source_state_id = function.steps[0].source_state_id
        source_observation = source_states.get(source_state_id)
        entry_action = function.steps[0].action
        if _recoverable_package_mismatch(
            current_observation=observation,
            source_observation=source_observation,
        ):
            # The shared Checker owns expected-app recovery.  Do not attempt
            # OmniTransfer against the wrong application: admit the Function
            # so execute_function can run restore_target_app first, then map
            # the real entry action on the restored page.
            transfer_result = TransferResult(
                None,
                reason="checker_package_mismatch_preflight",
            )
            mapping_confidence = 1.0
            mapping_reason = "checker_package_mismatch_preflight"
            mapping_available = True
        elif not requires_contextual_mapping(entry_action.tool, entry_action.args):
            transfer_result = TransferResult(entry_action)
            mapping_confidence = 1.0
            mapping_reason = None
            mapping_available = True
        elif transfer is None:
            decision["rejection_reason"] = "function_transfer_unavailable"
            continue
        else:
            try:
                mapped = await attempt_transfer(
                    transfer,
                    function.steps[0].action,
                    observation,
                    source_observation,
                    phase="recall.entry",
                )
                transfer_result = (
                    mapped
                    if isinstance(mapped, TransferResult)
                    else TransferResult(None, reason="omnitransfer_result_invalid")
                )
            except Exception as error:  # noqa: BLE001
                transfer_result = TransferResult(
                    None,
                    reason=f"omnitransfer_error:{error}",
                )
            mapping_confidence = next(
                (
                    float(transfer_result.detail[key])
                    for key in (
                        "absolute_contextual_confidence",
                        "pair_confidence",
                        "score",
                    )
                    if transfer_result.detail.get(key) is not None
                ),
                None,
            )
            mapping_reason = transfer_result.reason
            mapping_available = transfer_result.action is not None
        decision["mapping_confidence"] = mapping_confidence
        decision["entry_mapping_reason"] = mapping_reason
        decision["entry_mapping_target"] = (
            transfer_result.action.to_dict()
            if transfer_result.action is not None
            else None
        )
        if not mapping_available:
            decision["rejection_reason"] = (
                mapping_reason or "function_entry_mapping_unavailable"
            )
            continue
        decision["rejection_reason"] = None
        admitted.append((_score, function, decision))

    selected = admitted[: max(0, int(limit))]
    selected_ids = {function.id for _score, function, _audit in selected}
    for decision in decisions:
        decision["selected"] = decision["function_id"] in selected_ids
        if not decision["selected"] and not decision.get("coarse_selected"):
            decision["rejection_reason"] = (
                "function_excluded_for_run"
                if decision["function_id"] in exclude_function_ids
                else (
                    "function_not_agent_visible"
                    if decision.get("agent_visible") is False
                    else "coarse_candidate_limit"
                )
            )
        elif not decision["selected"] and decision["rejection_reason"] is None:
            decision["rejection_reason"] = "candidate_limit"

    return RecallResult(
        tuple(function for _score, function, _audit in selected),
        {
            "schema_version": RECALL_AUDIT_VERSION,
            "encoder": {
                "name": encoder.name,
                "version": encoder.version,
                "dimension": encoder.dimension,
                "weights_hash": getattr(encoder, "weights_hash", None),
                "architecture": getattr(encoder, "architecture", None),
                "backend": getattr(encoder, "backend", None),
                "checkpoint_sha256": getattr(
                    encoder, "checkpoint_sha256", None
                ),
            },
            "current_page": {
                "node_count": (
                    int(getattr(current_page, "node_count", 0))
                    if current_page is not None
                    else 0
                ),
            },
            "ranking_weights": {
                "page_similarity": PAGE_SIMILARITY_WEIGHT,
                "goal_lexical": GOAL_LEXICAL_WEIGHT,
            },
            "page_similarity_threshold": FUNCTION_PAGE_SIMILARITY_THRESHOLD,
            "coarse_candidate_function_ids": [
                function.id for _score, function, _audit in coarse
            ],
            "candidate_function_ids": [
                function.id for _score, function, _audit in selected
            ],
            "decisions": decisions,
        },
    )


def _score_function(
    goal: str,
    function: Function,
    *,
    current_observation: Observation,
    current_page: TreeEmbedding | None,
    source_states: Mapping[str, Observation | None],
    encoder: PageEncoder,
) -> dict[str, Any]:
    source_state_id = function.steps[0].source_state_id if function.steps else ""
    source_observation = source_states.get(source_state_id)
    page_match = match_function_page(
        current=current_page,
        current_observation=current_observation,
        source_observation=source_observation,
        encoder=encoder,
    )
    observed_page_similarity = float(page_match["page_similarity"] or 0.0)
    entry_page_override = (
        _entry_page_override(
            function.steps[0].action,
            source_observation=source_observation,
            current_observation=current_observation,
        )
        if function.steps
        else None
    )
    page_similarity = (
        1.0 if entry_page_override is not None else observed_page_similarity
    )
    goal_score = _jaccard(
        _tokens(goal),
        _tokens(f"{function.name} {function.description}"),
    )
    score = (
        PAGE_SIMILARITY_WEIGHT * page_similarity
        + GOAL_LEXICAL_WEIGHT * goal_score
    )

    return {
        "function_id": function.id,
        "agent_visible": function.agent_visible,
        "source_state_id": source_state_id,
        "page_similarity": page_similarity,
        "observed_page_similarity": observed_page_similarity,
        "entry_page_override": entry_page_override,
        "page_similarity_threshold": FUNCTION_PAGE_SIMILARITY_THRESHOLD,
        "page_match": page_match["matched"],
        "goal_lexical_score": goal_score,
        "score": score,
        "selected": False,
        "coarse_selected": False,
        "mapping_confidence": None,
        "entry_mapping_reason": None,
        "entry_mapping_target": None,
        "rejection_reason": None,
    }


def _entry_page_override(
    action: Action,
    *,
    source_observation: Observation | None,
    current_observation: Observation,
) -> str | None:
    if action.tool == "open_app":
        return "open_app"
    if _recoverable_package_mismatch(
        current_observation=current_observation,
        source_observation=source_observation,
    ):
        return "package_mismatch_checker"
    # Every canonical coordinate action, including Swipe, must enter through
    # contextual Transfer.  There is no direction-only semantic admission.
    return None


def _recoverable_package_mismatch(
    *,
    current_observation: Observation | None,
    source_observation: Observation | None,
) -> bool:
    """Return whether the shared expected-app Checker can run before mapping."""

    source_package = _observation_package(source_observation)
    current_package = _observation_package(current_observation)
    if not source_package or not current_package or source_package == current_package:
        return False
    return not any(
        marker in package.casefold()
        for package in (source_package, current_package)
        for marker in ("systemui", "permissioncontroller", "packageinstaller")
    )


def match_function_page(
    *,
    source_observation: Observation | None,
    encoder: PageEncoder,
    current_observation: Observation | None = None,
    current: TreeEmbedding | None = None,
) -> dict[str, Any]:
    """Compare pages using the canonical learned OmniTransfer v10 readout."""

    if source_observation is None:
        return _page_match_failure("function_source_page_missing")
    if current_observation is None and current is None:
        return _page_match_failure("function_current_page_missing")
    if current_observation is not None:
        source_package = _observation_package(source_observation)
        current_package = _observation_package(current_observation)
        if source_package and current_package and source_package != current_package:
            return _page_match_failure(
                "function_page_package_mismatch",
                source_package=source_package,
                current_package=current_package,
            )
    try:
        source_page = _embed_page(encoder, source_observation)
        current_page = current or _embed_page(encoder, current_observation)
    except (RuntimeError, ValueError) as error:
        return _page_match_failure(f"function_page_embedding_failed:{error}")
    if source_page is None or current_page is None:
        return _page_match_failure("function_page_embedding_missing")
    similarity = _cosine(current_page.vector, source_page.vector)
    matched = similarity >= FUNCTION_PAGE_SIMILARITY_THRESHOLD
    return {
        "matched": matched,
        "reason": None if matched else "function_page_similarity_below_threshold",
        "page_similarity": similarity,
        "minimum_page_similarity": FUNCTION_PAGE_SIMILARITY_THRESHOLD,
    }


def _page_match_failure(reason: str, **detail: Any) -> dict[str, Any]:
    return {
        "matched": False,
        "reason": reason,
        "page_similarity": None,
        "minimum_page_similarity": FUNCTION_PAGE_SIMILARITY_THRESHOLD,
        **detail,
    }


@timed("page_encoding")
def _embed_page(
    encoder: PageEncoder,
    observation: Observation | None,
) -> TreeEmbedding | None:
    if observation is None:
        return None
    try:
        page = encoder.embed(observation)
    except ValueError as error:
        if str(error) == "omnitransfer_page_xml_required":
            return None
        raise
    node_count = int(getattr(page, "node_count", len(page.elements)))
    if node_count <= 0 or float(np.linalg.norm(page.vector)) <= 0.0:
        return None
    return page


def _observation_package(observation: Observation) -> str:
    explicit = str(observation.package_name or "").strip()
    if explicit:
        return explicit
    packages = re.findall(r'\bpackage="([^"]+)"', str(observation.xml or ""))
    app_packages = [
        package
        for package in packages
        if package and package != "com.android.systemui"
    ]
    if not app_packages:
        return ""
    counts = {package: app_packages.count(package) for package in set(app_packages)}
    return min(counts, key=lambda package: (-counts[package], package))


def _cosine(left: np.ndarray, right: np.ndarray) -> float:
    denominator = float(np.linalg.norm(left) * np.linalg.norm(right))
    if denominator <= 0.0:
        return 0.0
    return max(0.0, min(1.0, float(np.dot(left, right) / denominator)))


def _tokens(value: str) -> set[str]:
    normalized = str(value or "").lower()
    tokens = set(re.findall(r"[a-z0-9_]+", normalized))
    chinese = "".join(re.findall(r"[\u4e00-\u9fff]+", normalized))
    if chinese:
        tokens.add(chinese)
        tokens.update(
            chinese[index : index + 2] for index in range(max(0, len(chinese) - 1))
        )
    return tokens


def _jaccard(left: set[str], right: set[str]) -> float:
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


__all__ = [
    "FUNCTION_PAGE_SIMILARITY_THRESHOLD",
    "GOAL_LEXICAL_WEIGHT",
    "PAGE_SIMILARITY_WEIGHT",
    "RECALL_AUDIT_VERSION",
    "RecallResult",
    "match_function_page",
    "recall_functions",
]
